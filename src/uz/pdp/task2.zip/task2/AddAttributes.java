package uz.pdp.task2;

public class AddAttributes {



    public int addAttributes(int attr1, int attr2){
        return attr1+attr2;
    }

    public double addAttributes(int attr1, double attr2){
        return attr1+attr2;
    }

    public double addAttributes(double attr1, double attr2, double attr3){
        return attr1+attr2+attr3;
    }

    public String addAttributes(String attr1, String attr2){
        return attr1+attr2;
    }

    public String addAttributes(int attr1, String attr2){
        return attr1+attr2;
    }


}
